﻿# VPS-MX By Kalix1 ( MOD NEW-ULTIMATE )
```
* UPDATE 24/11/2021
```
![logo](https://github.com/AAAAAEXQOSyIpN2JZ0ehUQ/VPS-MX-FREE/blob/main/Imagenes/VPS-MX-Free.png)

**Manager Script**

## :heavy_exclamation_mark: Requerimientos

* Un sistema operativo basado en Linux (Ubuntu o Debian) 
* Ubuntu 16.04 Server x86_64 / 18.04 Server x86_64
* Version 8.4 Preferente Ubuntu 20.04 Server x86_64
* Recomendamos Ubuntu 16.04 Server x86_64 / 18.04 Server x86_64
* Se recomienda usar una distro nueva o formatiada
* Importante esta version es de Casita Dev Team
* Importante su uso es totalmente gratuito 
* Source Code [Donwload](https://raw.githubusercontent.com/AAAAAEXQOSyIpN2JZ0ehUQ/VPS-MX-FREE/main/Install/VPS-MX-FREE_v8.4e.zip)

## :book: Installation

apt update -y; apt upgrade -y; wget https://raw.githubusercontent.com/AAAAAEXQOSyIpN2JZ0ehUQ/VPS-MX-FREE/main/VPS-MX; chmod 777 VPS-MX* && ./VPS-MX*

```
VPS-MX (las dependencias faltantes se instalarán automáticamente)
```
-------------------------------------------------------------------------------

## :scroll: Changelog

**VERSION: 8.4e**

https://raw.githubusercontent.com/AAAAAEXQOSyIpN2JZ0ehUQ/VPS-MX-FREE/main/Version

## :octocat: Credits

1. [@Kalix1 - Developer of VPS-MX](https://github.com/VPS-MX)
2. [@Rufu99 - Contributor](https://github.com/rudi9999)
3. [Casita Dev Team - Contributor](https://github.com/lacasitamx)
4. [illuminati Dev Team - Contributor](https://github.com/AAAAAEXQOSyIpN2JZ0ehUQ) 

```
☆ https://t.me/AAAAAEXQOSyIpN2JZ0ehUQ [  ⃘⃤꙰✰ ] ☆
```
